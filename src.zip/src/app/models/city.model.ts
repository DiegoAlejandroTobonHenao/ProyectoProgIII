export class CityModel{
    id?: String;
    code: String;
    name: String;
    _departmentId: String;
    departmentName?: String;
}