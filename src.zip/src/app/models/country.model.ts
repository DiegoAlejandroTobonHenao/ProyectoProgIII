export class CountryModel{
    id?: String;
    code: String;
    name: String;
}