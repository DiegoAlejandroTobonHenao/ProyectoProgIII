export class DepartmentModel{
    id?: String
    code: String;
    name: String;
    _countryId: String;
    countryName?: String;
}