import { UserModel } from './user.model';

export class VerifyEmail{
    user: UserModel;
    token: String;
}