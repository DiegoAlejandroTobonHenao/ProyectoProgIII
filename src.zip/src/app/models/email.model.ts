export class EmailModel{
    email: String;
    subject: String;
    message: String;
}