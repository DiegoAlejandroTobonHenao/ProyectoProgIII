import { Component, OnInit } from '@angular/core';
import { RequestModel } from 'src/app/models/request.model';
import { UserModel } from 'src/app/models/user.model';
import { SecurityService } from 'src/app/services/security.service';
import { RequestService } from 'src/app/services/request.service';
import { Router } from '@angular/router';

declare var openConfirmationModal: any;
declare var openPlatformModalMessage: any;
declare var openImageModal: any;
declare var openDesicisionModal: any;
declare var openCommentModal: any;

@Component({
  selector: 'app-property-evaluation',
  templateUrl: './property-evaluation.component.html',
  styleUrls: ['./property-evaluation.component.css']
})
export class PropertyEvaluationComponent implements OnInit {

  requestList: RequestModel[];
  currentUser: UserModel;
  codeToRemove: String;
  propertyImage: String;
  requestCode: String;
  p: Number = 1

  constructor(private secService: SecurityService, private requestService: RequestService, private router: Router) { }

  ngOnInit() {
    this.getUserInfo();
    this.getRequestsInfo();
  }

  getRequestsInfo() {
    this.requestService.loadRequests().subscribe(data => {
      setTimeout(() => {
        this.requestList = data;
      }, 400)
    });
  }

  getUserInfo() {
    this.secService.getUserInfo().subscribe(data => { this.currentUser = data });
  }

  openConfirmation(code) {
    this.codeToRemove = code;
    openConfirmationModal();
  }

  openImage(image) {
    this.propertyImage = image;
    openImageModal()
  }

  verifyStatus(status) {
    return status == "Send";
  }

  statusEvent(code) {
    let request: RequestModel = this.requestList.find(r => r.id == code);
    if (request.asesorCode == null || request.asesorCode == undefined) {
      request.status = "Under Consideration";
      request.asesorCode = this.currentUser.identification;
      request.comments = "Your property are under consideration";
      this.requestService.updateRequest(request).subscribe();
      setTimeout(() => {
        this.router.navigate(['asesor/advisorRequest'])
      },400)
    }else{
      openPlatformModalMessage("The request was already taken");
    }

  }

  desicionEvent(code) {
    this.requestCode = code;
    openDesicisionModal();
  }

  setDesicion(value) {
    let request: RequestModel = this.requestList.find(r => r.id == this.requestCode);
    if (value == 1) {
      request.status = "Accepted"
      this.requestService.updateRequest(request).subscribe();
    } else {
      request.status = "Rejected"
      this.requestService.updateRequest(request).subscribe();
      openCommentModal();
    }
  }

  setComment(comments) {
    let request: RequestModel = this.requestList.find(r => r.id == this.requestCode);
    request.comments = comments;
    this.requestService.updateRequest(request).subscribe();
  }

  removeElement() {
    this.requestService.deleteRequest(this.codeToRemove).subscribe();
    this.getRequestsInfo();
  }

}
