import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AsesorCreatorComponent } from './asesor-creator/asesor-creator.component';
import { AsesorEditorComponent } from './asesor-editor/asesor-editor.component';
import { AsesorListComponent } from './asesor-list/asesor-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';
import { PropertyEvaluationComponent } from './property-evaluation/property-evaluation.component';
import { AdvisorRequestComponent } from './advisor-request/advisor-request.component';

const routes: Routes = [
  {
    path: 'creator',
    component: AsesorCreatorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'editor/:id',
    component: AsesorEditorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: AsesorListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'request',
    component: PropertyEvaluationComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'advisorRequest',
    component: AdvisorRequestComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AsesorRoutingModule { }
