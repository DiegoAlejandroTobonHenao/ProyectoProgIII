import { Component, OnInit } from '@angular/core';
import { SecurityService } from 'src/app/services/security.service';
import { RequestModel } from 'src/app/models/request.model';
import { UserModel } from 'src/app/models/user.model';
import { RequestService } from 'src/app/services/request.service';

declare var openConfirmationModal: any;
declare var openImageModal: any;
declare var openDesicionModal: any;
declare var openCommentModal: any;

@Component({
  selector: 'app-advisor-request',
  templateUrl: './advisor-request.component.html',
  styleUrls: ['./advisor-request.component.css']
})
export class AdvisorRequestComponent implements OnInit {

  requestList: RequestModel[];
  currentUser: UserModel;
  codeToRemove: String;
  propertyImage: String;
  requestCode: String;
  p: Number = 1

  constructor(private secService: SecurityService, private requestService: RequestService) { }

  ngOnInit() {
    this.getUserInfo();
    this.getRequestsInfo();
  }

  getRequestsInfo(){
    this.requestService.loadRequestByAdvisor(this.currentUser.identification).subscribe(data => {
      this.requestList = data;
    });
  }

  getUserInfo(){
    this.secService.getUserInfo().subscribe(data => {
      this.currentUser = data
    });
  }

  openConfirmation(code){
    this.codeToRemove = code;
    openConfirmationModal();
  }

  openImage(image){
    this.propertyImage = image;
    openImageModal()
  }

  verifyStatus(status){
    return status == "Send";
  }

  statusEvent(code){
    let request: RequestModel = this.requestList.find(r => r.id == code);
    request.status = "Under Consideration";
    request.asesorCode = this.currentUser.identification;
    this.requestService.updateRequest(request).subscribe();
    this.getRequestsInfo();
  }

  desicionEvent(code){
    this.requestCode = code;
    openDesicionModal();
  }

  setDesicion(value){
    let request: RequestModel = this.requestList.find(r => r.id == this.requestCode);
    if (value == 1){
      request.status = "Accepted"
      this.requestService.updateRequest(request).subscribe();
    }else {
      request.status = "Rejected"
      this.requestService.updateRequest(request).subscribe();
      openCommentModal();
    }
  }

  setComment(comments){
    let request: RequestModel = this.requestList.find(r => r.id == this.requestCode);
    request.comments = comments;
    this.requestService.updateRequest(request).subscribe();
  }

  removeElement(){
    this.requestService.deleteRequest(this.codeToRemove).subscribe();
    this.getRequestsInfo();
  }

}
