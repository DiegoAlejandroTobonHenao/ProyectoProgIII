import { Component, OnInit } from '@angular/core';
import { UserModel } from 'src/app/models/user.model';
import { AdministratorService } from 'src/app/services/administrator.service';

declare var openConfirmationModal: any;

@Component({
  selector: 'app-administrator-list',
  templateUrl: './administrator-list.component.html',
  styleUrls: ['./administrator-list.component.css']
})
export class AdministratorListComponent implements OnInit {

  p: number = 1;
  adminList: UserModel[] = [];
  codeToRemove: String;

  constructor(private adminService: AdministratorService) { }

  ngOnInit() {
    this.loadAdministrators();
  }

  loadAdministrators = () => {
    this.adminService.loadAllAdministrators().subscribe(data => {
      setTimeout(() => {
        this.adminList = data
      }, 400)
    });
  }

  openConfirmation(code){
    this.codeToRemove = code;
    openConfirmationModal();
  }

  removeElement(){
    this.adminService.deleteAdministrator(this.codeToRemove).subscribe();
    this.loadAdministrators();
  }
}
