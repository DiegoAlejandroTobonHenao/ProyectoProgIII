import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdministratorCreatorComponent } from './administrator-creator/administrator-creator.component';
import { AdministratorListComponent } from './administrator-list/administrator-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';


const routes: Routes = [
  {
    path: 'creator',
    component: AdministratorCreatorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: AdministratorListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministratorAdminRoutingModule { }
