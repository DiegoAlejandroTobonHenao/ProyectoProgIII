import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministratorAdminRoutingModule } from './administrator-admin-routing.module';
import { AdministratorListComponent } from './administrator-list/administrator-list.component';
import { AdministratorCreatorComponent } from './administrator-creator/administrator-creator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [AdministratorListComponent, AdministratorCreatorComponent],
  imports: [
    CommonModule,
    AdministratorAdminRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ]
})
export class AdministratorAdminModule { }
