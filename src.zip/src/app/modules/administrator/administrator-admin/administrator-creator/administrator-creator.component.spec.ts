import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministratorCreatorComponent } from './administrator-creator.component';

describe('AdministratorCreatorComponent', () => {
  let component: AdministratorCreatorComponent;
  let fixture: ComponentFixture<AdministratorCreatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorCreatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministratorCreatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
