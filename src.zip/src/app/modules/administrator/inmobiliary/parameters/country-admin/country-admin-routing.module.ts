import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CountryCreatorComponent } from './country-creator/country-creator.component';
import { CountryEditorComponent } from './country-editor/country-editor.component';
import { CountryListComponent } from './country-list/country-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';


const routes: Routes = [
  {
    path: 'creator',
    component: CountryCreatorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'editor/:id',
    component: CountryEditorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: CountryListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CountryAdminRoutingModule { }
