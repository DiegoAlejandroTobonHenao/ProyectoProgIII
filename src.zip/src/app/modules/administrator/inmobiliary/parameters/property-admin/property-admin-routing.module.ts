import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PropertyCreatorComponent } from './property-creator/property-creator.component';
import { PropertyEditorComponent } from './property-editor/property-editor.component';
import { PropertyListComponent } from './property-list/property-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';


const routes: Routes = [
  {
    path: 'creator',
    component: PropertyCreatorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'editor/:id',
    component: PropertyEditorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: PropertyListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PropertyAdminRoutingModule { }
