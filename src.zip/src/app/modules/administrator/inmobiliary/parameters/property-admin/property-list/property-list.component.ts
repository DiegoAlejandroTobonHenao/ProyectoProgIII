import { Component, OnInit } from '@angular/core';
import { PropertyModel } from 'src/app/models/property.model';
import { PropertyService } from 'src/app/services/property.service';

declare var openConfirmationModal: any;
declare var openImageModal: any;

@Component({
  selector: 'app-property-list',
  templateUrl: './property-list.component.html',
  styleUrls: ['./property-list.component.css']
})
export class PropertyListComponent implements OnInit {

  p: number = 1;
  propertyList: PropertyModel[] = [];
  codeToRemove: String;
  propertyImage: String;

  constructor(private propertyService: PropertyService) { }

  ngOnInit() {
    this.loadProperties();
  }

  loadProperties = () => {
    this.propertyService.loadAllProperties().subscribe(data => {
      setTimeout(() => {
        this.propertyList = data;
      }, 400)
    });
    console.log(this.propertyList);
  }

  openConfirmation(code){
    this.codeToRemove = code;
    openConfirmationModal();
  }

  openImage(image){
    this.propertyImage = image;
    openImageModal()
  }

  removeElement(){
    this.propertyService.deleteProperty(this.codeToRemove).subscribe();
    setTimeout(() => {
      this.loadProperties();
    },200);
  }
}
