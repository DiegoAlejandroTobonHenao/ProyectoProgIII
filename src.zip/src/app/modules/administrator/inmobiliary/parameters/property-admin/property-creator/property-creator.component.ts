import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PropertyService } from 'src/app/services/property.service';
import { Router } from '@angular/router';
import { PropertyModel } from 'src/app/models/property.model';
import { CityService } from 'src/app/services/city.service';
import { CityModel } from 'src/app/models/city.model';

declare let openPlatformModalMessage: any;
declare var initMaterializeSelect: any

@Component({
  selector: 'app-property-creator',
  templateUrl: './property-creator.component.html',
  styleUrls: ['./property-creator.component.css']
})
export class PropertyCreatorComponent implements OnInit {

  frmValidator: FormGroup;
  cityList: CityModel[] = [];

  constructor(private fb: FormBuilder, private propertyService: PropertyService, private cityService: CityService, private router: Router) { }

  ngOnInit() {
    this.formGenerator();
    this.loadCities();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      initMaterializeSelect();
    },800);
  }

  get fv(){
    return this.frmValidator.controls;
  }

  formGenerator(){
    this.frmValidator = this.fb.group({
      code: ['', [Validators.required]],
      name: ['', [Validators.required, Validators.minLength(4)]],
      price: ['',[Validators.required]],
      city: ['', [Validators.required]],
      propertyType: ['', [Validators.required]],
      requestType: ['', [Validators.required]],
      description: ['',[Validators.required, Validators.minLength(20), Validators.maxLength(150)]],
      image:['',[Validators.required]]
    });
  }

  saveProperty(){
    if (this.frmValidator.invalid){
      openPlatformModalMessage("The form is invalid!")
    }else {
      let p: PropertyModel = {
        code: this.fv.code.value,
        name : this.fv.name.value,
        price: this.fv.price.value,
        city: this.getCity(this.fv.city.value),
        description: this.fv.description.value,
        propertyType: this.fv.propertyType.value,
        requestType: this.fv.requestType.value,
        image: this.fv.image.value
      };
      this.propertyService.saveNewProperty(p).subscribe();
      setTimeout(() => {
        this.router.navigate(['property/list'])
      },400);
    }
  }

  loadCities(){
    this.cityService.loadAllCities().subscribe(data => {
      this.cityList = data
    })
  }

  getCity(code){
    let city = this.cityList.find(c => c.code == code);
    return city.name;
  }
}
