import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PropertyService } from 'src/app/services/property.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PropertyModel } from 'src/app/models/property.model';
import { CityService } from 'src/app/services/city.service';
import { CityModel } from 'src/app/models/city.model';

declare let openPlatformModalMessage: any;
declare var initMaterializeSelect: any;

@Component({
  selector: 'app-property-editor',
  templateUrl: './property-editor.component.html',
  styleUrls: ['./property-editor.component.css']
})
export class PropertyEditorComponent implements OnInit {

  frmValidator: FormGroup;
  cityList: CityModel[];

  constructor(private route: ActivatedRoute, private fb: FormBuilder, private propertyService: PropertyService, private cityService: CityService, private router: Router) { }

  ngOnInit() {
    this.formGenerator();
    this.getPropertyInfo();
  }

  ngAfterViewInit() {
    initMaterializeSelect();
  }

  getPropertyInfo(){
    let code = this.route.snapshot.paramMap.get("id");
    if (code != undefined && code != null){
      let property = this.propertyService.searchProperty(code);
      if (property != undefined && property != null){
        this.fv.code.setValue(property.code);
        this.fv.name.setValue(property.name);
        this.fv.description.setValue(property.description);
        this.fv.price.setValue(property.price);
        this.fv.propertyType.setValue(property.propertyType);
        this.fv.requestType.setValue(property.requestType);
        this.fv.image.setValue(property.image);
      }else {
        openPlatformModalMessage(`The property with code ${code} does not exists!`)
        this.router.navigate(['/property/list']);
      }
    }else {
      openPlatformModalMessage("The URL is invalid!")
    }
  }

  get fv(){
    return this.frmValidator.controls;
  }

  formGenerator(){
    this.frmValidator = this.fb.group({
      code: ['', [Validators.required]],
      name: ['', [Validators.required, Validators.minLength(4)]],
      city: ['', [Validators.required]],
      price: ['',[Validators.required]],
      propertyType: ['', [Validators.required]],
      requestType: ['', [Validators.required]],
      description: ['',[Validators.required, Validators.minLength(20), Validators.maxLength(150)]],
      image:['',[Validators.required]]
    });
  }

  saveProperty(){
    if (this.frmValidator.invalid){
      openPlatformModalMessage("The form is invalid!")
    }else {
      let p: PropertyModel = {
        code: this.fv.code.value,
        name : this.fv.name.value,
        price: this.fv.price.value,
        city: this.getCity(this.fv.city.value),
        description: this.fv.description.value,
        propertyType: this.fv.propertyType.value,
        requestType: this.fv.requestType.value,
        image: this.fv.image.value
      };
      this.propertyService.updateProperty(p).subscribe();
      setTimeout(() => {
        this.router.navigate(['/property/list']);
      },5);
    }
  }

  loadCities(){
    this.cityService.loadAllCities().subscribe(data => {
      setTimeout(() => {
        this.cityList = data
      })
    })
  }

  getCity(code){
    let city = this.cityList.find(c => c.code == code);
    return city.name;
  }
}
