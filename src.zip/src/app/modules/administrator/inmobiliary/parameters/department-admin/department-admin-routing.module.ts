import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentCreatorComponent } from './department-creator/department-creator.component';
import { DepartmentEditorComponent } from './department-editor/department-editor.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';

const routes: Routes = [
  {
    path: 'creator',
    component: DepartmentCreatorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'editor/:id',
    component: DepartmentEditorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: DepartmentListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepartmentAdminRoutingModule { }
