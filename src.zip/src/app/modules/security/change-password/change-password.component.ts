import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { PasswordValidator } from 'src/app/helpers/validators/password.validator';
import { UserModel } from 'src/app/models/user.model';
import { SessionModel } from 'src/app/models/session.model';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  frmValidator: FormGroup;
  currentUser: UserModel;
  currentSession: SessionModel;

  constructor(private fb: FormBuilder, private secService: SecurityService, private router: Router) { }

  get fv() {
    return this.frmValidator.controls;
  }

  formGenerator() {
    this.frmValidator = this.fb.group({
      currentPassword: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(30)]],
      password: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(30)]],
      confirmPass: ['', [Validators.required]]
    }, { validator: PasswordValidator.incorrectPassword });
  }

  getUser(){
    this.secService.getUserInfo().subscribe(data => {
      this.currentUser = data
    })
  }

  getSession(){
    this.secService.getSessionInfo().subscribe(data => {
      this.currentSession = data
    })
  }

  changeEvent(){
    let newPass = this.secService.encrypt(this.fv.password.value);
    let currentPass = this.secService.encrypt(this.fv.currentPassword.value);
    if (currentPass == this.currentUser.secretKey){
      this.currentUser.secretKey = newPass;
      this.currentUser.password = currentPass;
      this.secService.updateUser(this.currentUser).subscribe();
      this.secService.changePassword(this.currentSession.id, currentPass, newPass).subscribe();
      openPlatformModalMessage("Password change succesfully");
      this.router.navigate(['/home']);
    }else {
      openPlatformModalMessage("Your current password is invalid");
    }
  }

  ngOnInit() {
    this.formGenerator();
    this.getUser();
    this.getSession();
  }

}
