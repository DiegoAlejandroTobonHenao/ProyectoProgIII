import { Component, OnInit } from '@angular/core';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { SessionModel } from 'src/app/models/session.model';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  sessionInfo: SessionModel;

  constructor(private secService: SecurityService, private router: Router) { }

  ngOnInit() {
    this.secService.getSessionInfo().subscribe(session =>{
      this.sessionInfo = session;
    });
    this.secService.logoutUser(this.sessionInfo.id).subscribe();
    this.router.navigate(["/home"]);
  }

}
