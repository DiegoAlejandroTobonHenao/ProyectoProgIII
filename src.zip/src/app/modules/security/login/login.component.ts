import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { HttpClient} from '@angular/common/http';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  fgValidation: FormGroup;
  captchaResponse: String;
  serverResponse: any;
  
  constructor(private fb: FormBuilder, private secService: SecurityService, private router: Router, private http: HttpClient) { }

  fgValidationBuilder(){
    this.fgValidation = this.fb.group({
      username: ['a01homecolombia@gmail.com', [Validators.required, Validators.minLength(5), Validators.maxLength(40), Validators.email]],
      password: ['12345', [Validators.required, Validators.minLength(5), Validators.maxLength(25), Validators.pattern("")]]
    });
  }

  loginEvent(){
    let u = this.fg.username.value;
    let p = this.secService.encrypt(this.fg.password.value)
    this.secService.loginUser(u, p).subscribe(data => {
      if(data != null && data != undefined){
        console.log(data);
        this.secService.saveLoginInfo(data);
        this.router.navigate(['/home']);
      }else {
        openPlatformModalMessage("The data is invalid!")
      }
    });
  }

  getUser(email){
    let user = this.secService.getUserByEmail(email);
    return user.emailVerified == true;
  }

  get fg(){
    return this.fgValidation.controls;
  }

  ngOnInit() {
    this.fgValidationBuilder();
  }

  verifyRecaptcha(){
    return this.captchaResponse != null;
  }

  public beforeSubmittingForm(response: String) {
    this.captchaResponse = response;
  }
}
