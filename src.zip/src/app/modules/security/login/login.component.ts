import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UserModel } from 'src/app/models/user.model';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  fgValidation: FormGroup;
  captchaResponse: String;
  userList: UserModel[] = [];

  constructor(private fb: FormBuilder, private secService: SecurityService, private router: Router, private http: HttpClient) { }

  fgValidationBuilder() {
    this.fgValidation = this.fb.group({
      username: ['a01homecolombia@gmail.com', [Validators.required, Validators.minLength(5), Validators.maxLength(40), Validators.email]],
      password: ['12345', [Validators.required, Validators.minLength(5), Validators.maxLength(25), Validators.pattern("")]]
    });
  }

  loginEvent() {
    let u = this.fg.username.value;
    let p = this.secService.encrypt(this.fg.password.value)
    let exists = this.userList.find(user => user.email == u && user.secretKey == p)
    console.log(exists);
    if (exists) {
      this.secService.loginUser(u, p).subscribe(data => {
      this.secService.saveLoginInfo(data);
      this.router.navigate(['/home']);
      });
    } else {
      openPlatformModalMessage("Invalid data");
    }
  }

  get fg() {
    return this.fgValidation.controls;
  }

  ngOnInit() {
    this.fgValidationBuilder();
    this.loadUsers();
  }

  loadUsers(){
    this.secService.loadAllUsers().subscribe(data => {
      console.log(data)
      this.userList = data
    })
  }

  verifyRecaptcha() {
    return this.captchaResponse != null;
  }

  public beforeSubmittingForm(response: String) {
    this.captchaResponse = response;
  }
}
