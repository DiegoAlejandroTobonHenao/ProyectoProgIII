import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { UserModel } from 'src/app/models/user.model';
import { ClientService } from 'src/app/services/client.service';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  fgValidation: FormGroup;
  userList: UserModel[] = [];

  constructor(private fb: FormBuilder, private secService: SecurityService, private clientService: ClientService, private router: Router) { }

  fgValidationBuilder() {
    this.fgValidation = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(40), Validators.email]]
    });
  }

  passwordEvent() {
    let email = this.fg.username.value;
    let user = this.userList.find(u => u.email == email);
    if (user) {
      let password = this.secService.generateToken();
      user.password = this.secService.encrypt(password);
      user.secretKey = this.secService.encrypt(password);
      console.log(user)
      this.secService.updateUser(user).subscribe();
      let subject: String = "New Password";
      let message: String = `This is the new password: ${password}`
      this.secService.sendEmail(email, subject, message).subscribe();
      openPlatformModalMessage("Please verify your email address");
      this.router.navigate(['/home']);
    } else {
      openPlatformModalMessage("Your email address doesn't exist")
    }
  }

  get fg() {
    return this.fgValidation.controls;
  }

  getUsers() {
    this.secService.loadAllUsers().subscribe(data => {
      this.userList = data;
    })
  }

  ngOnInit() {
    this.fgValidationBuilder();
    this.getUsers();
  }

}
