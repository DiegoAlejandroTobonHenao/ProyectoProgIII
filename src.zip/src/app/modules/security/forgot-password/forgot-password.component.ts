import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SecurityService } from 'src/app/services/security.service';
import { Router } from '@angular/router';
import { UserModel } from 'src/app/models/user.model';
import { ClientService } from 'src/app/services/client.service';

declare var openPlatformModalMessage: any;

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  fgValidation: FormGroup;
  captchaResponse: String;
  serverResponse: any;
  
  constructor(private fb: FormBuilder, private secService: SecurityService, private clientService: ClientService, private router: Router) { }

  fgValidationBuilder(){
    this.fgValidation = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(40), Validators.email]]
    });
  }

  passwordEvent(){
    let u = this.fg.username.value;
    let user: UserModel = this.secService.getUserByEmail(u);
    if (user != null && user != undefined){
      let password = this.secService.generateToken();
      user.password = this.secService.encrypt(password);
      this.clientService.updateClient(user).subscribe();
      let subject: String = "New Password";
      let message: String = `This is the new password: ${password}`
      this.secService.sendEmail(u, subject, message);
      openPlatformModalMessage("Please verify your email address");
    } else {
      openPlatformModalMessage("Your email address doesn't exist")
    }
  }

  get fg(){
    return this.fgValidation.controls;
  }

  ngOnInit() {
    this.fgValidationBuilder();
  }

}
