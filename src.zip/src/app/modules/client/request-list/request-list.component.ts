import { Component, OnInit } from '@angular/core';
import { SecurityService } from 'src/app/services/security.service';
import { RequestService } from "src/app/services/request.service";
import { RequestModel } from 'src/app/models/request.model'; 
import { UserModel } from 'src/app/models/user.model';

declare var openConfirmationModal: any;
declare var openImageModal: any;
declare var openCommentModal: any;

@Component({
  selector: 'app-request-list',
  templateUrl: './request-list.component.html',
  styleUrls: ['./request-list.component.css']
})
export class RequestListComponent implements OnInit {

  requestList: RequestModel[];
  currentUser: UserModel;
  codeToRemove: String;
  propertyImage: String;
  requestComments: String;
  p: Number = 1

  constructor(private secService: SecurityService, private requestService: RequestService) { }

  ngOnInit() {
    this.getUserInfo();
    this.getRequestsInfo();
  }

  getRequestsInfo(){
    this.requestService.loadRequestsByClient(this.currentUser.identification).subscribe(data => {
      setTimeout(() => {
        this.requestList = data
      },400)
    });
  }

  getUserInfo(){
    this.secService.getUserInfo().subscribe(data => {this.currentUser = data});
  }

  openConfirmation(code){
    this.codeToRemove = code;
    openConfirmationModal();
  }

  openImage(image){
    this.propertyImage = image;
    openImageModal()
  }

  openComments(comments){
    this.requestComments = comments;
    openCommentModal();
  }

  verifyStatus(status){
    return status == "Send";
  }

  verifyStatus2(status){
    return status == "Under Consideration";
  }

  verifyDesicion(status){
    return status = "Accepted" || status == "Rejected";
  }

  removeElement(){
    this.requestService.deleteRequest(this.codeToRemove).subscribe();
    this.getRequestsInfo();
  }

}
