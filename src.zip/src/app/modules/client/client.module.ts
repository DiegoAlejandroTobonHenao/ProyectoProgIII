import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientRoutingModule } from './client-routing.module';
import { ClientCreatorComponent } from './client-creator/client-creator.component';
import { ClientListComponent } from './client-list/client-list.component';
import { ClientEditorComponent } from './client-editor/client-editor.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { RequestListComponent } from './request-list/request-list.component';


@NgModule({
  declarations: [ClientCreatorComponent, ClientListComponent, ClientEditorComponent, RequestListComponent],
  imports: [
    CommonModule,
    ClientRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule
  ]
})
export class ClientModule { }
