import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientCreatorComponent } from './client-creator/client-creator.component';
import { ClientEditorComponent } from './client-editor/client-editor.component';
import { ClientListComponent } from './client-list/client-list.component';
import { RequestListComponent } from './request-list/request-list.component';
import { AuthenticationRequiredGuard } from 'src/app/helpers/guards/authentication-required.guard';

const routes: Routes = [
  {
    path: 'creator',
    component: ClientCreatorComponent
  },
  {
    path: 'editor/:id',
    component: ClientEditorComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'list',
    component: ClientListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: 'request',
    component: RequestListComponent,
    canActivate: [AuthenticationRequiredGuard]
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/list'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
